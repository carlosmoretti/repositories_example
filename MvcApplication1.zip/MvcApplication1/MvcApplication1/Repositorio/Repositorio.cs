﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication1.Repositorio
{
    public abstract class Repositorio<TEntity> : IRepositorio<TEntity> where TEntity : class
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly System.Data.Entity.DbSet<TEntity> _context;

        public Repositorio(IUnitOfWork unitOfWork)
        {
            _context = ((MvcApplication1.Models.ProjetoContexto)unitOfWork).Set<TEntity>();
            _unitOfWork = unitOfWork;
        }

        public IUnitOfWork UnitOfWork { get { return _unitOfWork; } }
        public System.Data.Entity.DbSet<TEntity> Context { get { return _context; } }

        public TEntity Inserir(TEntity entity) {
            _context.Add(entity);
            return entity;
        }

        public TEntity Atualizar(TEntity entity)
        {
            ((MvcApplication1.Models.ProjetoContexto)_unitOfWork).Entry(entity).State = System.Data.EntityState.Modified;
            return entity;
        }

        public void Excluir(TEntity entity)
        {
            _context.Remove(entity);
        }

        public TEntity Obter(System.Linq.Expressions.Expression<Func<TEntity, bool>> filter)
        {
            return _context.FirstOrDefault(filter);
        }

        public IQueryable<TEntity> ObterTodos()
        {
            return _context;
        }
    }
}