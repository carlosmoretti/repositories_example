﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication1.Repositorio
{
    public interface IUnitOfWork
    {
        public int Commit();
        System.Threading.Tasks.Task<int> CommitAsync();

        public void Rollback;
    }
}