﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcApplication1.Models;

namespace MvcApplication1.Repositorio
{
    public class RepositorioDeTarefas : Repositorio<Tarefas>, IRepositorioDeTarefas
    {
        public RepositorioDeTarefas(IUnitOfWork unitOfWork)
            : base(unitOfWork)
        {

        }

        public IQueryable<Tarefas> ObterPorDataDeInicio(DateTime dataDeInicio)
        {
            return Context.Where(item => item.DataDeInicio == dataDeInicio);
        }
    }

    public interface IRepositorioDeTarefas : IRepositorio<Tarefas>
    {
        // Quando não existe o método na interface IRepositorio, você pode implementa-lo aqui !
        IQueryable<Tarefas> ObterPorDataDeInicio(DateTime dataDeInicio);
    }
}