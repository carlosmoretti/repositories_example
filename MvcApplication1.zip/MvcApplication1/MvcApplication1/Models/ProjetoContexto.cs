﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.Threading.Tasks;
using MvcApplication1.Repositorio;

namespace MvcApplication1.Models
{
    public class ProjetoContexto : DbContext, IUnitOfWork
    {
        public DbSet<Tarefas> Tarefas { get; set; }

        public int Commit()
        {
            return SaveChanges();
        }

        public Task<int> CommitAsync()
        {
            return CommitAsync();
        }

        public void Rollback()
        {
            ChangeTracker.Entries().ToList()
                .ForEach(entry => entry.State = System.Data.EntityState.Unchanged);
        }
    }
}