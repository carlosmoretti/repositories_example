﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication1.Controllers
{
    public class TarefasController : Controller
    {
        private readonly Repositorio.IRepositorioDeTarefas _repositorioDeTarefas;
        public TarefasController(Repositorio.IRepositorioDeTarefas repositorioDeTarefas)
        {
            _repositorioDeTarefas = repositorioDeTarefas;
        }

        public ActionResult Index()
        {
            return View(_repositorioDeTarefas.ObterTodos());
        }

    }
}
